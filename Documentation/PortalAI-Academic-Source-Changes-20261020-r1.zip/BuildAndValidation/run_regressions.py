from pathlib import Path
import sys, unittest, json, time
from unittest.mock import patch
root=Path(sys.argv[1]).resolve()
sys.path[:0]=[str(root/'Maintenance/Tests'),str(root/'Agent'),str(root/'ControlCenter'),str(root/'Tools')]
names=['test_gui_stop_contract','test_account_gate','test_media_policy','test_chat_handoff',
       'test_chat_task_checkpoint','test_chat_summary_recovery','test_settings_surfaces_tk',
       'test_native_workflow_guards','test_linux_installer_receipt','test_mission_runner',
       'test_small_model_chat','test_chat_context_budget','test_chat_reasoning_continuation',
       'test_mission_context','test_profile_media']
loader=unittest.TestLoader();suite=loader.loadTestsFromNames(names)
import test_profile_media
if not (root/'Music/ACE-Step-1.5/acestep/api_server.py').exists():
    test_profile_media.ProfileMedia.test_ace_current_installed_source_compiles_without_importing_models=unittest.skip(
        'ACE vendor source is a separately downloaded installer component; synthetic profile routing tests still run.')(
        test_profile_media.ProfileMedia.test_ace_current_installed_source_compiles_without_importing_models)
start=time.monotonic()
# This account-gate test already mocks process execution; give its resolver a
# real interpreter path without installing the recipient runtime in the payload.
with patch('portable_runtime.bootstrap_python',return_value=Path(sys.executable)):
    result=unittest.TextTestRunner(verbosity=1).run(suite)
data={'root':str(root),'modules':names,'tests':result.testsRun,'seconds':round(time.monotonic()-start,2),
      'passed':result.wasSuccessful(),'skips':[(str(t),reason) for t,reason in result.skipped],
      'failures':[(str(t),err) for t,err in result.failures], 'errors':[(str(t),err) for t,err in result.errors]}
Path(sys.argv[2]).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
raise SystemExit(0 if result.wasSuccessful() else 1)
