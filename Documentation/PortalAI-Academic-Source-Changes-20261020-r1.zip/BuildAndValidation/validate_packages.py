from pathlib import Path
import ast, hashlib, importlib.util, json, subprocess, sys, tarfile, zipfile
from academic_policy import asset_allowed, blocked_name, POLICY_TEXT

WORK=Path(__file__).parent
STAGE=WORK/'packages'
VERIFY=WORK/'final-verify'
REPORT={'scope':'Exact final archives; no model/runtime downloads or live user accounts. Native runtime execution not tested.', 'platforms':{}}

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def module(path):
    spec=importlib.util.spec_from_file_location('academic_installer_verify',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def checked(root):
    count=0
    for p in root.rglob('*.py'):
        if p.relative_to(root).parts[0] in ('Agent','ControlCenter','Launchers','Tools','Installer'):
            ast.parse(p.read_bytes(),filename=str(p));count+=1
    assert (root/'Agent/Academic_Instructions.txt').read_text(encoding='utf-8')==POLICY_TEXT
    assert all(asset_allowed(m) for m in json.loads((root/'Agent/hardware_profiles.json').read_bytes())['models'])
    assert not any(blocked_name(p.name) for p in (root/'Workflows').rglob('*') if p.is_file())
    return count

def tests(platform,root):
    log=WORK/('academic-tests-'+platform+'.txt')
    run=subprocess.run([sys.executable,'-B','-X','utf8',str(WORK/'test_academic.py'),str(root)],capture_output=True,text=True,encoding='utf-8',timeout=60)
    log.write_text(run.stdout+run.stderr,encoding='utf-8')
    if run.returncode:raise RuntimeError(log.read_text(encoding='utf-8'))
    return {'tests':15,'passed':True,'runtime':'Windows host; platform payload source'}

def windows():
    archive=next(STAGE.glob('*Windows*.zip'));dest=VERIFY/'Windows';dest.mkdir(parents=True)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None;z.extractall(dest)
    for r in json.loads((dest/'PACKAGE_SHA256.json').read_bytes()):
        assert sha(dest/r['path'])==r['sha256'] and (dest/r['path']).stat().st_size==r['bytes']
    manifest=json.loads((dest/'release.json').read_bytes())
    assert manifest['edition']=='Academic'
    assert sha(dest/'payload.zip')==manifest['payload']['sha256']
    app=dest/'application'
    with zipfile.ZipFile(dest/'payload.zip') as z:
        assert z.testzip() is None
        assert set(z.namelist())=={r['member'] for r in manifest['payload']['members']}
        for r in manifest['payload']['members']:
            data=z.read(r['member']);assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
        z.extractall(app)
    assert not (app/'Utilities/Portable Abliterator').exists()
    core=module(app/'PortalAI/Installer/Windows/installer_core.py')
    ids=[c['id'] for c in manifest['components']]
    plans=[[],ids]+[[c['id']] for c in manifest['components'] if not c.get('required')]
    for selected in plans:
        chosen,artifacts,files,space=core.plan(manifest,selected)
        assert all(asset_allowed(a) for a in artifacts)
        assert any(c['id']=='text-small' for c in chosen)
    # Ensure maliciously substituting a standard manifest or forbidden URL cannot start a download.
    bad={**manifest,'edition':'Standard'}
    try:core.plan(bad,[])
    except ValueError:pass
    else:raise AssertionError('Nonacademic manifest accepted')
    root=app/'PortalAI'
    REPORT['platforms']['Windows']={'archive_sha256':sha(archive),'payload_files':len(manifest['payload']['members']),
        'component_plans_checked':len(plans),'python_files_parsed':checked(root),'academic_tests':tests('Windows',root)}
    print('Windows manifest, payload, plans and Academic tests passed',flush=True)
    proc=subprocess.run([str(dest/'PortalAI-Academic-Install.exe'),'--verify-bootstrap'],timeout=60)
    assert proc.returncode==0
    REPORT['platforms']['Windows']['bootstrap']=json.loads((dest/'installer-selfcheck.json').read_text(encoding='utf-8'))
    run=subprocess.run([sys.executable,'-B','-X','utf8',str(WORK/'run_regressions.py'),str(root),str(WORK/'final-regressions.json')],capture_output=True,text=True,encoding='utf-8',timeout=90)
    (WORK/'final-regressions.txt').write_text(run.stdout+run.stderr,encoding='utf-8')
    if run.returncode:raise RuntimeError(run.stdout+run.stderr)
    REPORT['platforms']['Windows']['regressions']=json.loads((WORK/'final-regressions.json').read_bytes())

def native(platform):
    archive=next(STAGE.glob('*'+platform+'*.tar.gz'));dest=VERIFY/platform;dest.mkdir(parents=True)
    with tarfile.open(archive) as t:t.extractall(dest,filter='data')
    package=next(dest.iterdir());manifest=json.loads((package/'manifest.json').read_bytes())
    for line in (package/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1);assert sha(package/name)==digest
    assert manifest['edition']=='Academic'
    expected=manifest['components']['payload.tar.gz']['sha256'] if platform=='Linux' else manifest['artifacts']['payload.tar.gz']['sha256']
    assert sha(package/'payload.tar.gz')==expected
    app=dest/'application';app.mkdir()
    with tarfile.open(package/'payload.tar.gz') as t:
        for item in t.getmembers():
            if item.isfile() and item.name.endswith(('.sh','.command')):assert item.mode&0o111, item.name
        t.extractall(app,filter='data')
    base=next((WORK/'baseline'/platform).iterdir())
    for p in base.iterdir():
        if p.name.startswith(('python-runtime','llama.cpp-source')):assert sha(p)==sha(package/p.name)
    script=package/('install.sh' if platform=='Linux' else 'install-macos.sh')
    subprocess.run(['C:/Program Files/Git/bin/bash.exe','-n',str(script)],check=True,timeout=30)
    REPORT['platforms'][platform]={'archive_sha256':sha(archive),'bundled_runtimes_unchanged':True,'shell_syntax_passed':True,
        'python_files_parsed':checked(app/'PortalAI'),'academic_tests':tests(platform,app/'PortalAI'),'physical_install_tested':False}
    print(platform+' manifest, payload, shell and Academic tests passed',flush=True)

if __name__=='__main__':
    VERIFY.mkdir(exist_ok=True)
    windows()
    native('Linux');native('Mac')
    (WORK/'validation.json').write_text(json.dumps(REPORT,indent=2)+'\n',encoding='utf-8')
