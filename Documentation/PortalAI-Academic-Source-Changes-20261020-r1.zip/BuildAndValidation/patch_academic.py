"""Build reproducible Academic source copies from checksum-verified releases."""
from pathlib import Path
import ast, json, shutil, hashlib, zipfile, tarfile, sys
from academic_policy import NOTICE, POLICY_TEXT, asset_allowed, blocked_name, enforce_policy

WORK = Path(__file__).parent
CHANGES = []

def replace(path, old, new, count=1):
    s=path.read_text(encoding='utf-8-sig')
    if s.count(old)!=count: raise RuntimeError(f'{path}: expected {count}, got {s.count(old)}: {old[:90]}')
    path.write_text(s.replace(old,new),encoding='utf-8',newline='\n')

def insert_function(path, name, code, *, replace_body=False):
    s=path.read_text(encoding='utf-8-sig'); tree=ast.parse(s)
    matches=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    if len(matches)!=1: raise RuntimeError(f'{path}: {name}: {len(matches)} matches')
    node=matches[0]; body=node.body
    if isinstance(body[0],ast.Expr) and isinstance(body[0].value,ast.Constant) and isinstance(body[0].value.value,str):body=body[1:]
    start=body[0].lineno-1
    lines=s.splitlines(keepends=True); indent=' '*(node.col_offset+4)
    added=''.join(indent+line+'\n' for line in code.splitlines())
    # Preserve docstrings; replace only executable body when requested.
    lines[start:node.end_lineno if replace_body else start]=[added]
    result=''.join(lines); ast.parse(result)
    path.write_text(result,encoding='utf-8',newline='\n')

def append(path, text):
    with path.open('a',encoding='utf-8',newline='\n') as f:f.write('\n'+text+'\n')

def prune_assets(path):
    s=path.read_text(encoding='utf-8-sig'); tree=ast.parse(s)
    for n in tree.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ASSETS' for t in n.targets):
            if not isinstance(n.value,ast.List):raise RuntimeError(str(path))
            keep=[ast.get_source_segment(s,x) for x in n.value.elts if not blocked_name(ast.get_source_segment(s,x))]
            lines=s.splitlines(keepends=True)
            lines[n.lineno-1:n.end_lineno]=['ASSETS = [\n'+',\n'.join(keep)+'\n]\n']
            path.write_text(''.join(lines),encoding='utf-8',newline='\n')
            return
    raise RuntimeError('No asset list '+str(path))

def patch(root):
    a=root/'Agent'; c=root/'ControlCenter'; t=root/'Tools'
    shutil.copyfile(WORK/'academic_policy.py',a/'academic_policy.py')
    (a/'Academic_Instructions.txt').write_text(POLICY_TEXT,encoding='utf-8',newline='\n')
    cfg=json.loads((a/'hardware_profiles.json').read_bytes())
    cfg=enforce_policy(cfg)
    (a/'hardware_profiles.json').write_text(json.dumps(cfg,indent=2)+'\n',encoding='utf-8')
    config=json.loads((a/'config.json').read_bytes())
    for key in list(config['comfy']['workflows']):
        if key.endswith('_uncensored'):config['comfy']['workflows'][key]=config['comfy']['workflows'][key.replace('_uncensored','_official')]
    (a/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
    p=a/'small_vision_assets.json'
    p.write_text(json.dumps([x for x in json.loads(p.read_bytes()) if asset_allowed(x)],indent=2)+'\n',encoding='utf-8')

    insert_function(a/'runtime_policy.py','load_policy',
        'from academic_policy import enforce_policy\nreturn enforce_policy(json.loads((root / "Agent/hardware_profiles.json").read_text(encoding="utf-8")))',replace_body=True)
    insert_function(a/'runtime_policy.py','select_model','from academic_policy import enforce_policy\npolicy = enforce_policy(policy)')
    insert_function(a/'runtime_policy.py','automatic_models','from academic_policy import enforce_policy\npolicy = enforce_policy(policy)')
    insert_function(a/'model_preferences.py','merge','from academic_policy import enforce_policy')
    replace(a/'model_preferences.py',"    result.setdefault('media', {}).update(saved.get('media', {}))\n    return result", "    result.setdefault('media', {}).update(saved.get('media', {}))\n    return enforce_policy(result)")
    insert_function(a/'model_preferences.py','effective','from academic_policy import enforce_policy\nbaseline = enforce_policy(baseline)')
    insert_function(a/'model_preferences.py','media_variant',"return 'standard'",replace_body=True)
    insert_function(a/'model_preferences.py','personal','from academic_policy import enforce_policy\npolicy = enforce_policy(policy)')
    insert_function(a/'chat_selection.py','selected_variant',"return 'standard'",replace_body=True)
    insert_function(a/'chat_selection.py','choice_changes',
        "from academic_policy import enforce_policy, standard_selection\npolicy = enforce_policy(policy)\nuncensored = False\nif selection is not None: selection = standard_selection(selection)")
    insert_function(a/'chat_vision_policy.py','candidates','from academic_policy import enforce_policy\npolicy = enforce_policy(policy)')
    insert_function(a/'chat_vision_policy.py','select','from academic_policy import enforce_policy\npolicy = enforce_policy(policy)')
    insert_function(a/'sd15_variants.py','normalize_variant',"return 'standard'",replace_body=True)
    insert_function(a/'ai_tools.py','select_variant',"from academic_policy import NOTICE\nreturn 'official', NOTICE",replace_body=True)
    insert_function(a/'ai_tools.py','_default_variant',
        "from academic_policy import NOTICE\nargs.uncensored = False\nargs.official = True\nargs.variant_reason = NOTICE\nreturn 'official', NOTICE",replace_body=True)
    insert_function(a/'ai_tools.py','workflow_key',"return f'{kind}_official'",replace_body=True)
    # Normalize flags once at CLI admission as well, including combined workflows.
    p=a/'ai_tools.py'; s=p.read_text(encoding='utf-8')
    marker='    args = parser.parse_args()'
    if marker not in s:
        marker='    args = p.parse_args()'
    if marker not in s: raise RuntimeError('CLI argument assignment not found')
    replace(p,marker,marker+"\n    if hasattr(args, 'uncensored'): args.uncensored = False\n    if hasattr(args, 'official'): args.official = True")
    insert_function(a/'media_policy.py','image_plan',"variant = 'standard'")
    insert_function(a/'native_flux.py','plan',"variant = 'official'")
    insert_function(a/'native_flux.py','command',"if profile.get('model_variant') == 'uncensored':\n    from academic_policy import NOTICE\n    raise ValueError(NOTICE)")
    insert_function(a/'native_video.py','video_plan',"variant = 'official'")
    insert_function(a/'native_video.py','command',"if plan.get('model_variant') == 'uncensored':\n    from academic_policy import NOTICE\n    raise ValueError(NOTICE)")
    insert_function(a/'vace_reference.py','prepare','uncensored = False')
    insert_function(a/'video_range_edit_bridge.py','video_range_edit','uncensored = False\nofficial = True')
    for name in ('_comfy_inpaint_image','video_inpaint'):insert_function(a/'media_edit_bridge.py',name,"variant = 'official'")
    insert_function(a/'model_variants.py','first_pass',"from academic_policy import NOTICE\nreturn 'official', NOTICE",replace_body=True)
    insert_function(a/'model_variants.py','require_flux_alternate',"from academic_policy import NOTICE\nraise ValueError(NOTICE)",replace_body=True)
    replace(a/'model_variants.py',"'chat_default': 'Automatic hardware-fit, uncensored preferred; existing saved selections retained'", "'chat_default': 'Academic: standard only; automatic hardware fit'")
    replace(a/'model_variants.py',"'media_default': 'auto'", "'media_default': 'standard', 'edition': 'Academic', 'variant_locked': True")
    replace(a/'model_variants.py',"'policy': 'Media auto lets Nice choose a supported standard/uncensored pair for the request. Media standard/uncensored: omit flags unless the user overrides it. --uncensored/--official select actual pairs only; chat preference never selects media. Retain normal specialists where no filter was found. Change tasks only if lost capabilities are acceptable. Never replay effectful work or switch because of a refusal. Keep memory/storage/account/Stop gates.'", "'policy': 'Academic: standard models only. Alternate catalog entries are reference metadata and unavailable to students. Keep normal specialists, memory/storage/account/Stop gates.'")
    insert_function(a/'comfy_bridge.py','workflow',"key = key.replace('_uncensored', '_official')")
    insert_function(a/'comfy_bridge.py','workflow_file',"from academic_policy import blocked_name, NOTICE\nif blocked_name(relative_path): raise ValueError(NOTICE)")
    insert_function(a/'comfy_bridge.py','queue','from academic_policy import check_workflow\ncheck_workflow(wf)')
    replace(c/'native_chat.py','        return "".join(pieces).strip()',
        '        from academic_policy import instruction_suffix\n        pieces.append(instruction_suffix(self.root))\n        return "".join(pieces).strip()')
    # Mission budgets count this suffix too; it survives context compaction.
    replace(a/'mission_context.py','    def messages(value):',
        '    from academic_policy import instruction_suffix\n    instruction += instruction_suffix(store.root)\n    def messages(value):')
    replace(a/'assistant_guidance.py',
        '"Chat and media variants are independent. Media auto: choose a supported variant for the request. "\n        "Media standard/uncensored: omit variant unless the user overrides it. Never switch on refusal or replay a tool. "',
        '"PortalAI Academic uses standard/censored chat and media models only. Variant controls and flags do not enable alternates. "\n        "Refuse unethical or obscene requests; never use a tool to evade a refusal or replay a completed tool. "')
    insert_function(c/'chat_effort_ui.py','_variant_changed','self.uncensored.set(False)\nreturn',replace_body=True)
    replace(c/'chat_effort_ui.py',"        self.variant_check.pack(side='left', padx=(4, 2))",
        "        self.variant_check.pack(side='left', padx=(4, 2))\n        self.variant_check.configure(state='disabled')\n        from academic_policy import bind_help\n        bind_help(self.variant_check)")
    replace(c/'settings_page.py',"        self.poll_id=self.after(250,self.poll)",
        "        from academic_policy import bind_help\n        for key in ('variant_preference', 'media_variant'):\n            self.variables[key].set('standard')\n            self.selectors[key].configure(state='disabled')\n            bind_help(self.selectors[key])\n        self.poll_id=self.after(250,self.poll)")
    replace(c/'settings_page.py',
        'Chat model and Uncensored choices save immediately and sync with chat effort: Fast 1.7B, Balanced 4B, Deep 27B. Loading happens on the next request or Startup. Backend and context changes still need Save or Startup. Media has its own independent setting.', NOTICE)
    insert_function(c/'settings_page.py','_chat_choice_selected',
        "if key == 'variant_preference':\n    self.variables[key].set('standard')\n    return")
    insert_function(c/'settings_page.py','_changed',
        "if key in ('variant_preference', 'media_variant'):\n    if self.variables[key].get() != 'standard': self.variables[key].set('standard')\n    self._dirty.discard(key)\n    return")
    # Readable choice descriptions survive palette/widget recreation.
    append(c/'media_choices.py',"from academic_policy import NOTICE as _ACADEMIC_NOTICE\nfor _key in CHOICES['media_variant']:\n    CHOICES['media_variant'][_key] = (CHOICES['media_variant'][_key][0], _ACADEMIC_NOTICE)\n")
    append(c/'help_catalog.py',"from academic_policy import NOTICE as _ACADEMIC_NOTICE\nTOPICS['academic'] = {'title': 'PortalAI Academic', 'category': 'Getting started', 'aliases': ['academic', 'uncensored', 'censored', 'chat variant', 'media models'], 'body': _ACADEMIC_NOTICE}\nfor _topic in TOPICS.values():\n    if any(_word in _topic.get('body', '').lower() for _word in ('uncensored', 'variant')):\n        _topic['body'] = _ACADEMIC_NOTICE + '\\n\\n' + _topic['body']\n")
    for name in ('import_foundation_assets.py','import_media_assets.py','import_media_variants.py','import_native_flux.py'):
        prune_assets(t/name)
    for name in ('install','download'):
        insert_function(t/'import_foundation_assets.py',name,'from academic_policy import require_asset\nrequire_asset(asset)')
    replace(t/'import_small_vision.py',"    entries = [row for row in entries if row['variant'] in variants]",
        "    from academic_policy import asset_allowed\n    entries = [row for row in entries if row['variant'] == 'standard' and asset_allowed(row)]")
    # Old launchers remain recognizable but cannot directly select excluded weights.
    for p in (root/'Launchers').iterdir():
        if p.suffix.lower() not in ('.py','.ps1','.cmd','.bat','.sh'):continue
        s=p.read_text(encoding='utf-8-sig')
        new=s.replace('Qwen3.8-27B-Abliterated-Q4_K_M.gguf','Qwen3.8-27B-Q4_K_M.gguf').replace('Qwen3.8-27B-Abliterated-Q5_K_M.gguf','Qwen3.8-27B-Q4_K_M.gguf').replace('mmproj-Qwen3.8-27B-BF16.gguf','mmproj-Qwen3.8-27B-Standard-BF16.gguf')
        if s!=new:p.write_text(new,encoding='utf-8',newline='\n')
    # Graphs for alternates and historical updater scripts are not student assets.
    for p in list((root/'Workflows').rglob('*')):
        if p.is_file() and blocked_name(p.name):p.unlink()
    for p in list(t.glob('patch*.py'))+[t/'refresh_clean_installers.py',t/'smoke_qwen4_abliterated.py']:
        if p.is_file():p.unlink()
    master=sorted(root.glob('PortableAI_Master_Instructions_v*.txt'))
    for p in master:append(p,POLICY_TEXT)
    (root/'Documentation/PortalAI_Academic.txt').write_text(
        'PORTALAI ACADEMIC — 2026-10-20 r1\n\n'+NOTICE+'\n\n'
        'Censored/standard mode is permanent in this edition. The existing variant controls are inert. '
        'Right-click (Control-click on Mac) for Academic help. Saved variant preferences and legacy flags '
        'are normalized to standard. Chat size, hardware selection, scientific tools, normal media workflows, '
        'accounts, Stop and memory/storage admission retain their existing behavior.\n\n'
        'Uncensored/abliterated weights, alternate SD1.5 DreamShaper, alternate Wan/FLUX weights, anatomical LoRAs '
        'and Portable Abliterator are excluded. Catalogs and historical diagnostics may still name them; '
        'absence of these optional assets is intentional. Install only Academic updates.\n\n'
        'Agent/Academic_Instructions.txt is appended at the end of the native chat system harness and mission '
        'instruction harness, even with the optional manual disabled. A built-in copy remains effective if the '
        'sidecar is missing or altered. The shared master text also contains the appendix.\n\n'
        'This is application policy and model guidance, not an OS security boundary or a guarantee of model '
        'refusals. For controlled student deployment, retain administrator credentials with staff, use standard/guest '
        'student accounts and OS permissions protecting application files. Existing platform/hardware limitations '
        'remain; standard media models do not acquire a new output classifier.\n',encoding='utf-8')
    append(root/'README.md','PortalAI Academic: '+NOTICE+' See Documentation/PortalAI_Academic.txt.')

def main():
    for platform in ('Windows','Linux','Mac'):
        base=WORK/'app'/platform
        target=WORK/'academic-app'/platform
        if target.exists():
            # Only this builder's disposable, resolved workspace output is reset.
            if not target.resolve().is_relative_to(WORK.resolve()):raise RuntimeError('Unsafe stage')
            shutil.rmtree(target)
        shutil.copytree(base,target)
        patch(target/'PortalAI')
        ablator=target/'Utilities/Portable Abliterator'
        if ablator.exists():
            if not ablator.resolve().is_relative_to(target.resolve()):raise RuntimeError('Unsafe utility stage')
            shutil.rmtree(ablator)
        before={str(p.relative_to(base)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in base.rglob('*') if p.is_file()}
        after={str(p.relative_to(target)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in target.rglob('*') if p.is_file()}
        changed=[{'path':name,'before_sha256':before.get(name),'after_sha256':after.get(name)} for name in sorted(before.keys()|after.keys()) if before.get(name)!=after.get(name)]
        CHANGES.append({'platform':platform,'changes':changed})
        for p in (target/'PortalAI').rglob('*.py'):
            if p.relative_to(target/'PortalAI').parts[0] in ('Agent','ControlCenter','Launchers','Tools','Installer'):
                ast.parse(p.read_bytes(),filename=str(p))
        print(platform, 'patched',len(changed),'files',flush=True)
    (WORK/'source_changes.json').write_text(json.dumps(CHANGES,indent=2)+'\n')

if __name__=='__main__':main()
