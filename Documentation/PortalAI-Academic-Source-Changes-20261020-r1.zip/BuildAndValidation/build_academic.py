"""Package only Academic source copies; never write to an installed PortalAI root."""
from pathlib import Path
import ast, copy, hashlib, importlib.util, io, json, shutil, subprocess, sys, tarfile, zipfile
from academic_policy import NOTICE, POLICY_TEXT, asset_allowed, blocked_name
from patch_academic import replace, insert_function

WORK=Path(__file__).parent
STAGE=WORK/'packages'
RELEASE='PortalAI-Academic-2026.10.20-r1'
REPORT={'release':RELEASE,'base_archives':{},'excluded_artifacts':[],'packages':{}}

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
def row(path):return dict(bytes=path.stat().st_size,sha256=sha(path))
def py_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def safe_file(path):
    parts={p.casefold() for p in path.parts}
    if parts & {'private','outputs','__pycache__','.git','connections'}:raise RuntimeError('Non-public artifact: '+str(path))

def setup_windows_sources(root):
    source=root/'PortalAI/Installer/Windows'
    shutil.copyfile(WORK/'academic_policy.py',source/'academic_policy.py')
    insert_function(source/'installer_core.py','plan','from academic_policy import validate_installer_manifest\nvalidate_installer_manifest(manifest)')
    insert_function(source/'installer_core.py','fetch','from academic_policy import require_asset\nrequire_asset(item)')
    p=source/'Installer.cs'
    replace(p,'new [] { "installer_core.py", "engine_cli.py" }','new [] { "installer_core.py", "engine_cli.py", "academic_policy.py" }')
    replace(p,'PortalAI clean installer — r14','PortalAI Academic installer — 2026.10.20 r1')
    replace(p,'PortalAI will be installed beside this installer:', 'PortalAI Academic (standard/censored only) will be installed beside this installer:')
    replace(p,'data.ContainsKey("name") ? data["name"] : data["id"]','data.ContainsKey("label") ? data["label"] : data["id"]')
    return source

def native_script(platform,package,root):
    linux=platform=='Linux';name='install.sh' if linux else 'install-macos.sh'
    p=package/name;s=p.read_text(encoding='utf-8')
    s=s.replace('PortalAI Linux','PortalAI Academic Linux') if linux else s.replace('PortalAI Mac','PortalAI Academic Mac')
    if linux:
        marker='"$PYTHON" -B -I "$STAGE/PortalAI/Tools/install_linux_clean.py" --install-core'
        command='"$PYTHON" -B -I "$STAGE/PortalAI/Tools/import_foundation_assets.py" --install --only qwen1.7-q8'
    else:
        marker='"$PYTHON" -B "$ROOT/Tools/macos_installer_smoke.py"'
        command='"$PYTHON" -B "$ROOT/Tools/import_foundation_assets.py" --install --only qwen1.7-q8'
        s=s.replace('Models are not bundled; add a compatible GGUF under LLM/models first.', 'The standard Qwen 1.7B chat model was installed. Academic mode is permanent.')
        s=s.replace('<string>ai.portalai.desktop</string>','<string>ai.portalai.academic.desktop</string>')
        s=s.replace('<key>CFBundleName</key><string>PortalAI</string>','<key>CFBundleName</key><string>PortalAI Academic</string>')
    if s.count(marker)!=1:raise RuntimeError('Native insertion failed')
    s=s.replace(marker,marker+'\n\n# Academic installs one standard chat model; no alternate downloads.\n'+command)
    p.write_text(s,encoding='utf-8',newline='\n')
    nested=root/'PortalAI/Installer'/platform/name
    if nested.exists():nested.write_text(s,encoding='utf-8',newline='\n')

def add_standard_flux_dependencies(root,manifest):
    # Removing the alternate encoder makes the standard Qwen4 encoder necessary.
    path=root/'PortalAI/Tools/import_native_flux.py'
    f=py_module(root/'PortalAI/Tools/import_foundation_assets.py','academic_foundation_build')
    encoder=next(x for x in f.ASSETS if x['id']=='qwen4-q4')
    vae=next(a for c in manifest['components'] for a in c['artifacts'] if any(x['dest'].endswith('/vae/flux2-vae.safetensors') for x in a['members']))
    v={'id':'native-flux-standard-vae','url':vae['url'],'size':vae['bytes'],'sha256':vae['sha256'],
       'dest':'Generative/ComfyUI_windows_portable/ComfyUI/models/vae/flux2-vae.safetensors'}
    s=path.read_text(encoding='utf-8');marker='\ndef main():'
    if s.count(marker)!=1:raise RuntimeError('Native Flux list insertion failed')
    s=s.replace(marker,'\nASSETS.extend('+repr([encoder,v])+')\n'+marker)
    path.write_text(s,encoding='utf-8',newline='\n')

def windows():
    out=STAGE/'Windows';out.mkdir(parents=True,exist_ok=True)
    root=WORK/'academic-app/Windows'
    manifest=json.loads((WORK/'baseline/Windows/release.json').read_bytes())
    original=copy.deepcopy(manifest)
    add_standard_flux_dependencies(root,manifest)
    source=setup_windows_sources(root)
    # Capture and prune actual download records, including plain-named anatomy files.
    components=[]
    for component in manifest['components']:
        before=component['artifacts'];kept=[]
        for artifact in before:
            if component['id']=='abliterator-runtime' or not asset_allowed(artifact):
                REPORT['excluded_artifacts'].append({'component':component['id'],'id':artifact['id'],**row_from_asset(artifact)})
            else:kept.append(artifact)
        if not kept:continue
        component['artifacts']=kept
        component['label']=component['label'].replace('standard and abliterated','standard only').replace('standard and DreamShaper','standard').replace('standard and alternate','standard')
        if component['id']=='comfy-models-optional':component['label']='Additional standard ComfyUI image and video models'
        if component['id']=='text-small':component['required']=True
        if component['id']=='flux-model-subset-optional':component['depends_on']=list(dict.fromkeys(component.get('depends_on',[])+['text-4b']))
        components.append(component)
    # Expose the already-pinned standard Deep model; the original omitted it.
    f=py_module(root/'PortalAI/Tools/import_foundation_assets.py','academic_standard_models_build')
    assets=[]
    for x in f.ASSETS:
        if x['id'] in ('qwen27-standard-q4','qwen27-standard-projector'):
            assets.append({'id':x['id'],'url':x['url'],'bytes':x['size'],'sha256':x['sha256'],'format':'file',
                           'members':[{'dest':'PortalAI Windows/'+x['dest'],'bytes':x['size'],'sha256':x['sha256']}]})
    components.append({'id':'text-27b-standard','label':'Standard 27B Deep chat and vision model (optional)','required':False,'artifacts':assets})
    manifest['components']=components
    ids={x['id'] for x in components}
    manifest['generated_receipts']=[d for d in manifest.get('generated_receipts',[]) if not blocked_name(d['dest'])
        and set(d['components'])<=ids and all(not blocked_name(x['dest']) for x in d['files'])
        and asset_allowed(d.get('data',{}))]
    manifest['edition']='Academic';manifest['release']=RELEASE+'-Windows-x64'
    manifest['base_release']=original['release'];manifest['notice']=NOTICE
    manifest['validation']='ACADEMIC_REGRESSION_AND_PACKAGE_CHECKS; FULL_RECIPIENT_INSTALL_NOT_TESTED'
    for key in ('owner_waiver_sha256','prior_validation','supersedes_release'):manifest.pop(key,None)
    manifest['limitations']=[x for x in manifest['limitations'] if 'waived' not in x.lower()]
    manifest['limitations'].append('Academic restrictions are application policy and instruction guidance; no OS isolation or guaranteed model refusal is claimed.')
    manifest['repair_scope']=['Academic standard-only routing','inert variant controls with context help','excluded downloads','mandatory instruction suffix']
    mapping={x['member']:x['dest'] for x in original['payload']['members']}
    rows=[]
    with zipfile.ZipFile(out/'payload.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(root.rglob('*')):
            if not p.is_file():continue
            relative=p.relative_to(root);safe_file(relative)
            key=relative.as_posix();data=p.read_bytes()
            dest=mapping.get(key,'PortalAI Windows/'+key[len('PortalAI/'):] if key.startswith('PortalAI/') else key)
            info=zipfile.ZipInfo(key,(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,data)
            rows.append({'member':key,'dest':dest,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    manifest['payload'].update(**row(out/'payload.zip'),members=rows)
    dump(out/'release.json',manifest)
    compiler=Path('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe')
    command=[str(compiler),'/nologo','/target:winexe','/optimize+','/out:'+str(out/'PortalAI-Academic-Install.exe')]
    command+=['/reference:'+name for name in ('System.Windows.Forms.dll','System.Drawing.dll','System.Web.Extensions.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')]
    command+=['/resource:'+str(WORK/'python-bootstrap.zip')+',python-bootstrap.zip']
    command+=['/resource:'+str(source/name)+','+name for name in ('installer_core.py','engine_cli.py','academic_policy.py')]
    subprocess.run(command+[str(source/'Installer.cs')],check=True)
    guide=NOTICE+'\n\nExtract this entire ZIP into a new folder on the desired drive. Run PortalAI-Academic-Install.exe. '
    guide+='It installs PortalAI Windows and its launcher beside itself and refuses existing application folders. The title and help identify the Academic edition. '
    guide+='Internet is needed for pinned standard model/runtime downloads. The standard 1.7B chat model is required; 4B, 27B and standard vision/media components are optional. '
    guide+='Choose only components suited to recipient hardware. Original memory/storage/account/Stop checks remain.\n\n'
    guide+='Uncensored/abliterated models, anatomical LoRAs, DreamShaper, alternate Wan/FLUX weights and Portable Abliterator are excluded. '
    guide+='See PortalAI Windows/Documentation/PortalAI_Academic.txt after installation. Full clean recipient installation and generated-media acceptance are not tested.\n'
    (out/'START_HERE.txt').write_text(guide,encoding='utf-8')
    names=['PortalAI-Academic-Install.exe','release.json','payload.zip','START_HERE.txt']
    dump(out/'PACKAGE_SHA256.json',[{'path':n,**row(out/n)} for n in names])
    archive=STAGE/'PortalAI-Academic-Windows-Installer-20261020-r1-x64.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n in names+['PACKAGE_SHA256.json']:z.write(out/n,n)
    REPORT['packages']['Windows']={'file':archive.name,**row(archive),'payload_files':len(rows),'components':len(components)}
    REPORT['windows_bootstrap']=row(WORK/'python-bootstrap.zip')
    return manifest

def row_from_asset(a):return {'bytes':a['bytes'],'sha256':a['sha256'],'destinations':[x['dest'] for x in a['members']]}

def native(platform,win_manifest):
    base=next((WORK/'baseline'/platform).iterdir());out=STAGE/platform;out.mkdir(parents=True,exist_ok=True)
    for p in base.iterdir():
        if p.name!='payload.tar.gz':shutil.copyfile(p,out/p.name)
    root=WORK/'academic-app'/platform
    add_standard_flux_dependencies(root,win_manifest)
    native_script(platform,out,root)
    manifest=json.loads((out/'manifest.json').read_bytes())
    manifest['base_release']=manifest['release'];manifest['release']=RELEASE+'-'+platform
    manifest['edition']='Academic';manifest['notice']=NOTICE
    manifest['standard_chat_download']='Pinned Qwen3 1.7B Q8; installed by the Academic installer'
    manifest['verification_scope']='Academic Python/source and archive checks on Windows; physical Linux/macOS installation untested.'
    # Preserve original Unix modes, including ELF libraries and launcher scripts.
    with tarfile.open(base/'payload.tar.gz') as old:
        modes={m.name:m.mode for m in old.getmembers()}
    with tarfile.open(out/'payload.tar.gz','w:gz',compresslevel=6) as tar:
        for p in sorted(root.rglob('*')):
            if not p.is_file():continue
            rel=p.relative_to(root);safe_file(rel);name=rel.as_posix();data=p.read_bytes()
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=1792454400
            info.mode=modes.get(name,0o755 if p.suffix in ('.sh','.command') else 0o644)
            tar.addfile(info,io.BytesIO(data))
    if platform=='Linux':manifest['components']['payload.tar.gz']=row(out/'payload.tar.gz')
    else:
        manifest['application'].update(payload_sha256=sha(out/'payload.tar.gz'),payload_bytes=(out/'payload.tar.gz').stat().st_size,
                                       files=sum(1 for p in root.rglob('*') if p.is_file()))
        manifest['artifacts']['payload.tar.gz']=row(out/'payload.tar.gz')
    dump(out/'manifest.json',manifest)
    oldreadme=(out/'README.txt').read_text(encoding='utf-8')
    intro=('PORTALAI ACADEMIC — '+platform+' — 2026-10-20 r1\n\n'+NOTICE+'\n\n'
           'Extract into a new folder. Run '+('sh install.sh' if platform=='Linux' else 'bash install-macos.sh')+'. '
           'The default destination is PortalAI Academic '+platform+' beside the script. Existing destinations are refused. '
           'The installer downloads the pinned standard Qwen 1.7B chat model; no uncensored models or anatomical LoRAs are downloaded. '
           'Other standard models can be installed with the filtered Tools/import_foundation_assets.py and Tools/import_small_vision.py utilities. '
           'Original optional media/science capabilities and platform limitations remain.\n\n'
           'The Academic suffix is mandatory even when the manual is disabled. Variant controls are inert and retain right-click help. '
           'See Documentation/PortalAI_Academic.txt in the installed app. Physical recipient installation has not been tested.\n\n'
           'BASE PLATFORM REQUIREMENTS AND HISTORICAL RELEASE NOTES\nThe current Academic instructions above supersede older filenames and model setup advice below.\n\n')
    (out/'README.txt').write_text(intro+oldreadme,encoding='utf-8')
    names=[p.name for p in out.iterdir() if p.is_file() and p.name!='SHA256SUMS']
    (out/'SHA256SUMS').write_text(''.join(sha(out/n)+'  '+n+'\n' for n in sorted(names)),encoding='ascii')
    arch='x86_64' if platform=='Linux' else 'universal'
    archive=STAGE/f'PortalAI-Academic-{platform}-Installer-20261020-r1-{arch}.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
        for p in sorted(out.iterdir()):
            if not p.is_file():continue
            info=tarfile.TarInfo('PortalAI-Academic-'+platform+'-Installer-r1/'+p.name)
            data=p.read_bytes();info.size=len(data);info.mtime=1792454400;info.mode=0o755 if p.suffix=='.sh' else 0o644
            tar.addfile(info,io.BytesIO(data))
    REPORT['packages'][platform]={'file':archive.name,**row(archive)}

def main():
    STAGE.mkdir(exist_ok=True)
    for platform in ('Windows','Linux','Mac'):
        directory=Path('D:/Utilities')/f'PortalAI {platform} Installer'
        name=(directory/'LATEST.txt').read_text().splitlines()[0]
        REPORT['base_archives'][platform]={'file':name,**row(directory/name)}
    manifest=windows();print('Windows package built',flush=True)
    for p in ('Linux','Mac'):native(p,manifest);print(p+' package built',flush=True)
    for p in REPORT['packages'].values():(STAGE/(p['file']+'.sha256')).write_text(p['sha256']+'  '+p['file']+'\n',encoding='ascii')
    dump(WORK/'build_report.json',REPORT)

if __name__=='__main__':main()
