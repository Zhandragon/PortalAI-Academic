from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, tarfile, zipfile

WORK=Path(__file__).resolve().parent;BASE=WORK/'academic-r2'
report={'release':'Academic 2026.10.20 r2','scope':'Exact archive integrity and no-network policy/regression checks on Windows; physical Linux/Mac execution untested.','platforms':{}}
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(script,root,log):
    args=[sys.executable,'-B','-X','utf8',str(WORK/script),str(root)]
    if script=='run_regressions.py':args.append(str(log.with_suffix('.json')))
    result=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',timeout=110)
    log.write_text(result.stdout+result.stderr,encoding='utf-8')
    assert result.returncode==0,result.stdout+result.stderr
for platform in ('Windows','Linux','Mac'):
    package=BASE/'packages'/platform
    dest=BASE/'verify'/platform;dest.mkdir(parents=True,exist_ok=True)
    root=dest/'PortalAI'
    if platform=='Windows':
        manifest=json.loads((package/'release.json').read_bytes())
        assert sha(package/'payload.zip')==manifest['payload']['sha256']
        with zipfile.ZipFile(package/'payload.zip') as z:
            for row in manifest['payload']['members']:
                data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
            z.extractall(dest)
        for row in json.loads((package/'PACKAGE_SHA256.json').read_bytes()):assert sha(package/row['path'])==row['sha256']
        # Bootstrap selfcheck runs no application/model installation.
        subprocess.run([str(package/'PortalAI-Academic-Install.exe'),'--verify-bootstrap'],check=True,timeout=60)
    else:
        for line in (package/'SHA256SUMS').read_text().splitlines():
            digest,name=line.split('  ',1);assert sha(package/name)==digest
        with tarfile.open(package/'payload.tar.gz') as t:t.extractall(dest,filter='data')
        script=package/('install.sh' if platform=='Linux' else 'install-macos.sh')
        subprocess.run(['C:/Program Files/Git/bin/bash.exe','-n',str(script)],check=True,timeout=30)
    run('test_academic.py',root,BASE/(platform+'-baseline-tests.txt'))
    run('test_academic_r2.py',root,BASE/(platform+'-r2-tests.txt'))
    report['platforms'][platform]={'academic_tests':23,'passed':True,'physical_platform_execution':platform=='Windows','model_inference_tested':False}
    if platform=='Windows':
        run('run_regressions.py',root,BASE/'windows-regressions.txt')
        regression=json.loads((BASE/'windows-regressions.json').read_bytes());regression.pop('root',None)
        report['platforms'][platform]['regressions']=regression
    print('Academic r2 tests passed:',platform,flush=True)
(BASE/'VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
