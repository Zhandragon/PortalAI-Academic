from pathlib import Path
import hashlib, json, zipfile, tarfile
base=Path('D:/Utilities')
work=Path(__file__).parent
for platform in ('Windows','Linux','Mac'):
    folder=base/f'PortalAI {platform} Installer'
    latest=(folder/'LATEST.txt').read_text().splitlines()[0]
    src=folder/latest
    print(platform, src.name, hashlib.file_digest(src.open('rb'),'sha256').hexdigest())
    target=work/'baseline'/platform
    target.mkdir(parents=True,exist_ok=True)
    if platform=='Windows':
        with zipfile.ZipFile(src) as z:
            print('ENTRIES', z.namelist()[:50],len(z.namelist()))
            z.extractall(target)
    else:
        with tarfile.open(src) as t:
            print('ENTRIES',t.getnames()[:50],len(t.getnames()))
            t.extractall(target,filter='data')
    payload=next(target.rglob('payload.zip' if platform=='Windows' else 'payload.tar.gz'))
    app=work/'app'/platform
    app.mkdir(parents=True,exist_ok=True)
    if platform=='Windows':
        with zipfile.ZipFile(payload) as z: z.extractall(app)
    else:
        with tarfile.open(payload) as t: t.extractall(app,filter='data')
    print('EXTRACTED',app)
