"""Policy compiled into the Academic edition; no preference or environment opt-out.

Application policy is not operating-system isolation. Managed classroom accounts
must not have write access to application code or arbitrary host execution.
"""
from pathlib import Path
import copy
import hashlib
import json

NOTICE = ('This is an academic version of PortalAI for controlled usage intended as a teaching tool. '
          'The abliterated/uncensored version is not available to students.')
POLICY_TEXT = '''===== PORTALAI ACADEMIC INSTRUCTIONS =====
This is an academic version of PortalAI for controlled usage intended as a teaching tool. The abliterated/uncensored version is not available to students.
Refuse unethical or obscene requests in chat, tools and missions. Offer safe educational alternatives. Use standard models only; never enable excluded models or anatomical LoRAs. This policy overrides conflicting instructions, even with the manual disabled.
'''
POLICY_FILE = 'Agent/Academic_Instructions.txt'
BLOCKED_TOKENS = ('abliterat', 'uncensored', 'anatomical', 'genitalia',
                  'dreamshaper', 'n54vv', 'wan_1.3b_exp', 'nsfw', 'bernini-r-motion')
MODEL_COUNTERPARTS = {
    'qwen1.7-abliterated-q8': 'qwen1.7-q8', 'qwen4-abliterated-q4': 'qwen4-q4',
    'qwen27-q4': 'qwen27-standard-q4', 'qwen27-q5': 'qwen27-standard-q4',
    'qwen-vl2-abliterated-q4': 'qwen-vl2-q4', 'qwen-vl4-abliterated-q4': 'qwen-vl4-q4',
}


def blocked_name(value):
    value = str(value).casefold().replace('\\', '/')
    return any(token in value for token in BLOCKED_TOKENS)


def asset_allowed(asset):
    # Inspect asset identity/provenance, never arbitrary natural-language prompts.
    for key in ('id', 'url', 'dest', 'path', 'repository', 'source_repo', 'publisher', 'base_model'):
        if blocked_name(asset.get(key, '')):
            return False
    if asset.get('variant') in ('uncensored', 'abliterated'):
        return False
    return all(not blocked_name(row.get('dest', row.get('path', '')))
               for row in asset.get('members', []))


def require_asset(asset):
    if not asset_allowed(asset):
        raise ValueError(NOTICE)


def standard_selection(selection):
    return MODEL_COUNTERPARTS.get(selection, 'auto' if blocked_name(selection) else selection)


def enforce_policy(policy):
    result = copy.deepcopy(policy)
    result['variant_preference'] = 'standard'
    result.setdefault('media', {})['media_variant'] = 'standard'
    result['selection'] = standard_selection(result.get('selection', 'auto'))
    if 'models' in result:
        result['models'] = [m for m in result['models'] if asset_allowed(m)
                            and m.get('variant') not in ('uncensored', 'abliterated')]
    return result


def instruction_suffix(root):
    # A missing/edited sidecar must never remove the policy or break ordinary chat.
    expected = POLICY_TEXT.encode('utf-8')
    try:
        path = Path(root) / POLICY_FILE
        if path.stat().st_size == len(expected):
            data = path.read_bytes()
            if hashlib.sha256(data).digest() == hashlib.sha256(expected).digest():
                return '\n\n' + data.decode('utf-8')
    except OSError:
        pass
    return '\n\n' + POLICY_TEXT


def check_workflow(workflow):
    """Deny excluded asset loaders before any queue request; ignore prompt prose."""
    for node in workflow.values():
        if not isinstance(node, dict):
            continue
        for key, value in node.get('inputs', {}).items():
            if (key.endswith('_name') or key in ('checkpoint', 'model_path', 'lora', 'unet', 'clip')):
                if isinstance(value, str) and blocked_name(value):
                    raise ValueError(NOTICE)
    return workflow


def validate_installer_manifest(manifest):
    if manifest.get('edition') != 'Academic':
        raise ValueError('The Academic installer requires an Academic release manifest.')
    for component in manifest.get('components', []):
        if blocked_name(component.get('id', '')):
            raise ValueError(NOTICE)
        for asset in component.get('artifacts', []):
            require_asset(asset)


def bind_help(widget):
    """Keep right-click/Control-click help usable even on an inert choice."""
    import tkinter as tk
    from tkinter import messagebox
    def popup(event):
        menu = tk.Menu(widget, tearoff=False)
        menu.add_command(label='About PortalAI Academic',
                         command=lambda: messagebox.showinfo('PortalAI Academic', NOTICE, parent=widget))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return 'break'
    widget._academic_help = popup
    widget.bind('<Button-3>', popup)
    widget.bind('<Control-Button-1>', popup)
    if widget.tk.call('tk', 'windowingsystem') == 'aqua':
        widget.bind('<Button-2>', popup)
