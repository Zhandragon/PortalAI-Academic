"""Academic-only maintenance. Never reads/writes the normal distribution stage."""
from pathlib import Path
import ast, copy, hashlib, importlib.util, io, json, re, shutil, subprocess, tarfile, zipfile

WORK=Path(__file__).resolve().parent
OUT=WORK/'academic-r2'
STAGE=OUT/'packages'
CHANGES={}

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def replace(text,old,new):
    assert text.count(old)==1,old[:100]
    return text.replace(old,new)

WORKFLOW_GUARD='''def check_workflow(workflow):
    """Check loader fields, including nested/multiple adapters, before queuing.

    Prompt prose is deliberately not treated as a model filename. This is asset
    admission, not a content classifier or a boundary against editable code.
    """
    if not isinstance(workflow, dict):
        raise ValueError('Expected a workflow node mapping.')
    def asset_key(key):
        key = str(key).casefold()
        return (key.endswith(('_name', '_path', '_file')) or
                any(key == stem or key.startswith(stem + '_')
                    for stem in ('ckpt', 'checkpoint', 'model', 'unet', 'clip', 'lora', 'adapter', 'vae', 'text_encoder')))
    def inspect(value, is_asset=False):
        if isinstance(value, str):
            if is_asset and blocked_name(value):
                raise ValueError(NOTICE)
        elif isinstance(value, dict):
            for key, item in value.items():
                inspect(item, is_asset or asset_key(key))
        elif isinstance(value, (list, tuple)):
            # Graph edges refer to another node's output, not a model pathname.
            if len(value) == 2 and isinstance(value[0], str) and type(value[1]) is int and value[0] in workflow:
                return
            for item in value:
                inspect(item, is_asset)
    for node in workflow.values():
        if not isinstance(node, dict):
            continue
        inputs = node.get('inputs', {})
        if not isinstance(inputs, dict):
            raise ValueError('Expected a workflow input mapping.')
        for key, value in inputs.items():
            inspect(value, asset_key(key))
    return workflow
'''

CATALOG_APPEND='''
# Academic tool discovery exposes usable standard routes. Historical alternate
# names remain in public documentation, but are not instructions to load them.
from academic_policy import NOTICE as _ACADEMIC_NOTICE, blocked_name as _academic_blocked
for _row in CATALOG:
    _alternates = _row.pop('uncensored', [])
    if _alternates:
        _row['unavailable_variants'] = {'uncensored': {'available': False, 'reason': _ACADEMIC_NOTICE}}
        _row['status'] = 'academic_standard_only'
    for _key in ('uncensored_source', 'closest_alternatives', 'replacement_needed'):
        _row.pop(_key, None)
    if _academic_blocked(_row.get('source', '')):
        _row.pop('source', None)
    _row['selection'] = 'Academic: use the standard family and saved hardware/profile selection.'
    _sentences = _row.get('notes', '').split('. ')
    _row['notes'] = '. '.join(_s for _s in _sentences if not _academic_blocked(_s) and 'alternate' not in _s.casefold())
    _row['academic_notice'] = _ACADEMIC_NOTICE
    if 'filtering' in _row:
        _row['filtering'] += ' Academic instruction guidance does not add a separate media output classifier.'
'''

def content_changes(root):
    changes={}
    p=root/'Agent/academic_policy.py';text=p.read_text(encoding='utf-8')
    text=replace(text,'import json\n','import json\nfrom urllib.parse import unquote\n')
    text=replace(text,"value = str(value).casefold().replace('\\\\', '/')", "value = unquote(str(value)).casefold().replace('\\\\', '/')")
    blocked=json.loads((WORK/'build_report.json').read_bytes())['excluded_artifacts']
    hashes=sorted({r['sha256'] for r in blocked if r['component']!='abliterator-runtime'})
    text=replace(text,'def asset_allowed(asset):', 'KNOWN_EXCLUDED_DIGESTS = frozenset('+repr(hashes)+')\n\n\ndef asset_allowed(asset):')
    text=replace(text,'    # Inspect asset identity/provenance, never arbitrary natural-language prompts.',
        "    # Detect known excluded downloads even if their labels/URLs are renamed.\n    if str(asset.get('sha256', '')).casefold() in KNOWN_EXCLUDED_DIGESTS:\n        return False\n    if any(str(row.get('sha256', '')).casefold() in KNOWN_EXCLUDED_DIGESTS for row in asset.get('members', [])):\n        return False\n    # Inspect asset identity/provenance, never arbitrary natural-language prompts.")
    begin=text.index('def check_workflow(');end=text.index('\ndef validate_installer_manifest',begin)
    text=text[:begin]+WORKFLOW_GUARD+'\n'+text[end:]
    changes['Agent/academic_policy.py']=text

    p=root/'ControlCenter/bundle_inventory.py';text=p.read_text(encoding='utf-8')
    marker='    for name, present in d["backends"].items():'
    text=replace(text,marker,
        "    from academic_policy import MODEL_COUNTERPARTS, NOTICE\n"
        "    for model_id in MODEL_COUNTERPARTS:\n"
        "        rows['model_' + model_id] = ('EXCLUDED', 'Unavailable in Academic; intentionally omitted.')\n"
        "    rows['fluxAlt'] = ('EXCLUDED', 'Unavailable in Academic; intentionally omitted.')\n"+marker)
    changes['ControlCenter/bundle_inventory.py']=text

    p=root/'Agent/model_variants.py';text=p.read_text(encoding='utf-8')
    text=replace(text,"'default_source': 'Independent signed-in Media models setting. Initial auto lets Nice choose; omitted choices use standard.',",
        "'default_source': 'Academic policy: standard only; alternate models are unavailable.',\n        'uncensored_available': False,")
    changes['Agent/model_variants.py']=text+CATALOG_APPEND
    p=root/'Agent/mission_runner.py';text=p.read_text(encoding='utf-8')
    old='Chat and media preferences are independent. Media auto permits a supported per-request --uncensored/--official choice. Media standard/uncensored: omit flags unless the user explicitly overrides.'
    text=replace(text,old,'Academic policy permits standard models only. Uncensored flags and alternate catalog entries do not enable excluded models. Refuse unethical or obscene requests and never use a tool to evade a refusal.')
    changes['Agent/mission_runner.py']=text
    p=root/'Maintenance/Tests/test_mission_runner.py';text=p.read_text(encoding='utf-8')
    text=replace(text,"self.assertIn('Media standard/uncensored: omit flags unless the user explicitly overrides',prompt)",
        "self.assertIn('Academic policy permits standard models only.',prompt)\n        self.assertNotIn('Media auto permits a supported per-request --uncensored',prompt)")
    changes['Maintenance/Tests/test_mission_runner.py']=text
    p=root/'Agent/chat_vision_policy.py';text=p.read_text(encoding='utf-8')
    text=replace(text,'Install the matching Standard or Abliterated vision files.',
                 'Install a matching Standard vision model using the Academic installer; alternate models are unavailable.')
    changes['Agent/chat_vision_policy.py']=text
    p=root/'ControlCenter/settings_page.py';text=p.read_text(encoding='utf-8')
    text=replace(text,'It follows Uncensored and keeps your text choice.',
                 'Academic always uses standard vision companions and keeps your text choice.')
    changes['ControlCenter/settings_page.py']=text
    p=root/'ControlCenter/help_catalog.py';text=p.read_text(encoding='utf-8')
    text+='''
# Edition-specific help replaces inherited variant instructions while keeping
# the other controls' original documentation available.
_academic_help = {
    'settings': 'Chat size, backend, context budget and media profiles remain configurable. Chat variant and Media models are locked to standard; their controls do not enable alternates. Changes to backend/context still require Save or Startup. Right-click for control help.',
    'small_vision': 'Automatic image vision uses standard Qwen VL companions: 2B for Fast; 4B with a 2B fallback for Balanced. It preserves the saved text model and attachments. Install the matching standard model/projector with Academic setup. Memory admission and Stop checks still apply.',
    'native_image': 'Supported standard SD1.5 and FLUX profiles retain their existing CPU/Vulkan/CUDA hardware requirements. DreamShaper and alternate encoders are unavailable in Academic. Missing standard dependencies stop the job with an error; use the Academic import tools to install them. Standard media engines do not acquire a new output classifier.'}
for _key, _body in _academic_help.items():
    TOPICS[_key]['body'] = _ACADEMIC_NOTICE + '\\n\\n' + _body
'''
    changes['ControlCenter/help_catalog.py']=text
    doc=(root/'Documentation/PortalAI_Academic.txt').read_text(encoding='utf-8')
    doc=doc.replace('2026-10-20 r1','2026-10-20 r2')
    doc+='\nR2: excluded package rows are labeled EXCLUDED, tool discovery and mission guidance describe standard-only routes, and loader admission checks nested/multiple adapters plus known excluded download hashes. These checks do not add media output classification or OS isolation.\n'
    changes['Documentation/PortalAI_Academic.txt']=doc
    for name,data in changes.items():
        if name.endswith('.py'):ast.parse(data,filename=name)
    return {k:v.encode('utf-8') for k,v in changes.items()}

def rewrite_payload(platform,package):
    root=WORK/'final-verify'/platform/'application/PortalAI'
    changes=content_changes(root);CHANGES[platform]=changes
    app=OUT/'application'/platform/'PortalAI'
    shutil.copytree(root,app,dirs_exist_ok=True)
    for name,data in changes.items():(app/name).write_bytes(data)
    manifest_name='release.json' if platform=='Windows' else 'manifest.json'
    manifest=json.loads((package/manifest_name).read_bytes())
    manifest['release']=manifest['release'].replace('2026.10.20-r1','2026.10.20-r2')
    if platform=='Windows':
        mapping={r['member']:r for r in manifest['payload']['members']}
        with zipfile.ZipFile(WORK/'packages/Windows/payload.zip') as old, zipfile.ZipFile(package/'payload.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as new:
            for info in old.infolist():
                if info.is_dir():continue
                key=info.filename.removeprefix('PortalAI/')
                data=changes.get(key,old.read(info)) if info.filename.startswith('PortalAI/') else old.read(info)
                # Keep the embedded installer guard in sync with the application policy.
                if info.filename=='PortalAI/Installer/Windows/academic_policy.py':data=changes['Agent/academic_policy.py']
                new.writestr(info.filename,data)
                mapping[info.filename].update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
        manifest['payload'].update(bytes=(package/'payload.zip').stat().st_size,sha256=sha(package/'payload.zip'))
        source=OUT/'installer-source';shutil.copytree(root/'Installer/Windows',source,dirs_exist_ok=True)
        (source/'academic_policy.py').write_bytes(changes['Agent/academic_policy.py'])
        cs=(source/'Installer.cs').read_text();(source/'Installer.cs').write_text(cs.replace('2026.10.20 r1','2026.10.20 r2'))
        args=['C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe','/nologo','/target:winexe','/optimize+','/out:'+str(package/'PortalAI-Academic-Install.exe')]
        args+=['/reference:'+n for n in ('System.Windows.Forms.dll','System.Drawing.dll','System.Web.Extensions.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')]
        args+=['/resource:'+str(WORK/'python-bootstrap.zip')+',python-bootstrap.zip']
        args+=['/resource:'+str(source/n)+','+n for n in ('installer_core.py','engine_cli.py','academic_policy.py')]
        subprocess.run(args+[str(source/'Installer.cs')],check=True)
    else:
        with tarfile.open(WORK/'packages'/platform/'payload.tar.gz') as old,tarfile.open(package/'payload.tar.gz','w:gz',compresslevel=6) as new:
            for info in old:
                if not info.isfile():new.addfile(info);continue
                data=changes.get(info.name.removeprefix('PortalAI/'),old.extractfile(info).read())
                info.size=len(data);new.addfile(info,io.BytesIO(data))
        item={'bytes':(package/'payload.tar.gz').stat().st_size,'sha256':sha(package/'payload.tar.gz')}
        if platform=='Linux':manifest['components']['payload.tar.gz']=item
        else:
            manifest['artifacts']['payload.tar.gz']=item
            manifest['application'].update(payload_sha256=item['sha256'],payload_bytes=item['bytes'])
    dump(package/manifest_name,manifest)
    for n in ('START_HERE.txt','README.txt'):
        p=package/n
        if p.exists():p.write_text(p.read_text(encoding='utf-8').replace('2026-10-20 r1','2026-10-20 r2')+'\nAcademic r2: package status and guidance corrected; nested asset-loader and known-hash checks added.\n',encoding='utf-8')

def main():
    STAGE.mkdir(parents=True,exist_ok=True)
    for platform in ('Windows','Linux','Mac'):
        folder=STAGE/platform;shutil.copytree(WORK/'packages'/platform,folder,dirs_exist_ok=True)
        rewrite_payload(platform,folder)
        if platform=='Windows':
            # The r1 manifest uses a list of path/hash records.
            dump(folder/'PACKAGE_SHA256.json',[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(folder.iterdir()) if p.is_file() and p.name not in ('PACKAGE_SHA256.json','installer-selfcheck.json')])
            archive=STAGE/'PortalAI-Academic-Windows-Installer-20261020-r2-x64.zip'
            with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for p in sorted(folder.iterdir()):
                    if p.is_file() and p.name!='installer-selfcheck.json':z.write(p,p.name)
        else:
            (folder/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(folder.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
            arch='x86_64' if platform=='Linux' else 'universal'
            archive=STAGE/f'PortalAI-Academic-{platform}-Installer-20261020-r2-{arch}.tar.gz'
            with tarfile.open(archive,'w:gz',compresslevel=6) as t:
                for p in sorted(folder.iterdir()):
                    if not p.is_file():continue
                    info=t.gettarinfo(str(p),arcname=f'PortalAI-Academic-{platform}-Installer-r2/'+p.name)
                    info.mode=0o755 if p.suffix=='.sh' else 0o644;info.uid=info.gid=0;info.uname=info.gname=''
                    with p.open('rb') as f:t.addfile(info,f)
        print('Built Academic r2',platform,flush=True)
    with zipfile.ZipFile(OUT/'PortalAI-Academic-Source-Changes-20261020-r2.zip','w',zipfile.ZIP_DEFLATED) as z:
        for platform,changes in CHANGES.items():
            for name,data in changes.items():z.writestr(platform+'/ChangedFiles/PortalAI/'+name,data)
        z.write(Path(__file__),'BuildAndValidation/build_academic_r2.py')

if __name__=='__main__':main()
