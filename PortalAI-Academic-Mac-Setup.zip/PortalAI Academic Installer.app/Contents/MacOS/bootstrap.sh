#!/bin/bash
# PortalAI Academic online installer. Requires no host Python.
set -euo pipefail
SOURCE='https://raw.githubusercontent.com/Zhandragon/PortalAI-Academic/main/packages/20261020-r2/Mac'
ARCHIVE='PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz'
ARCHIVE_HASH='3db2b869a1c7e94f96f13788841bc6f51b28b2a15133b2bb7cffbbf84ecbc298'
TOP='PortalAI-Academic-Mac-Installer-r2'
PLATFORM='Mac'
OWNER='PortalAI-Academic-bootstrap-20261020-r2-Mac'
PREPARE_ONLY=0
SETUP=''
while [ "$#" -gt 0 ]; do
    case "$1" in
        --prepare-only) PREPARE_ONLY=1; shift ;;
        --directory) [ "$#" -ge 2 ] || { echo 'Missing setup directory.' >&2; exit 2; }; SETUP="$2"; shift 2 ;;
        *) echo 'Usage: bash installer [--directory PATH] [--prepare-only]' >&2; exit 2 ;;
    esac
done
if [ "$PREPARE_ONLY" -eq 0 ]; then
    [ "$(uname -s)" = Darwin ] || { echo 'This installer requires macOS.' >&2; exit 2; }
    case "$(uname -m)" in arm64|x86_64) ;; *) echo 'This installer requires an Apple silicon or Intel Mac.' >&2; exit 2 ;; esac
fi
printf '\nPortalAI Academic - %s Setup\n\n' "$PLATFORM"
printf '%s\n' 'This is an academic version of PortalAI for controlled usage intended as a teaching tool. The abliterated/uncensored version is not available to students.'
if [ -z "$SETUP" ]; then
    DEFAULT_SETUP="$HOME/PortalAI Academic $PLATFORM Setup"
    printf '\nSetup folder [%s]: ' "$DEFAULT_SETUP"
    IFS= read -r SETUP || exit 1
    SETUP="${SETUP:-$DEFAULT_SETUP}"
fi
case "$SETUP" in /*) ;; *) SETUP="$PWD/$SETUP" ;; esac
for tool in curl tar mktemp wc; do command -v "$tool" >/dev/null || { echo "Required tool is missing: $tool" >&2; exit 1; }; done
if command -v sha256sum >/dev/null 2>&1; then
    digest() { sha256sum "$1" | awk '{print $1}'; }
elif command -v shasum >/dev/null 2>&1; then
    digest() { shasum -a 256 "$1" | awk '{print $1}'; }
else echo 'SHA-256 tool missing (sha256sum or shasum).' >&2; exit 1
fi
if [ -e "$SETUP" ] && [ ! -d "$SETUP" ]; then echo 'Setup path is not a folder.' >&2; exit 1; fi
if [ -d "$SETUP" ] && [ -n "$(ls -A "$SETUP")" ]; then
    if [ ! -f "$SETUP/.portalai-academic-setup" ] || [ "$(cat "$SETUP/.portalai-academic-setup")" != "$OWNER" ]; then
        echo 'Choose a new, empty setup folder. This folder contains unrelated files.' >&2; exit 1
    fi
fi
mkdir -p "$SETUP"
SETUP=$(cd "$SETUP" && pwd -P)
printf '%s' "$OWNER" > "$SETUP/.portalai-academic-setup"
if ! mkdir "$SETUP/.bootstrap.lock" 2>/dev/null; then
    echo 'Another setup is running. If a prior setup was interrupted, remove the empty .bootstrap.lock folder after ensuring it is no longer running.' >&2; exit 1
fi
TEMP=''
cleanup() {
    if [ -n "$TEMP" ] && [ -f "$TEMP" ]; then rm -f "$TEMP"; fi
    rmdir "$SETUP/.bootstrap.lock" 2>/dev/null || true
}
trap cleanup EXIT
trap 'exit 130' INT TERM HUP
CACHE="$SETUP/downloads"
mkdir -p "$CACHE"
valid() { [ -f "$1" ] && [ "$(wc -c < "$1" | tr -d '[:space:]')" = "$2" ] && [ "$(digest "$1")" = "$3" ]; }
while IFS='|' read -r name size expected; do
    printf '\nVerifying/downloading %s\n' "$name"
    if ! valid "$CACHE/$name" "$size" "$expected"; then
        TEMP=$(mktemp "$CACHE/.download.XXXXXXXX")
        downloaded=0
        for attempt in 1 2 3; do
            if curl --fail --location --retry 2 --connect-timeout 20 --speed-time 90 --speed-limit 1024 --max-filesize "$size" --proto '=https' --proto-redir '=https' --output "$TEMP" "$SOURCE/$name"; then downloaded=1; break; fi
            if [ "$attempt" -lt 3 ]; then echo 'Retrying the interrupted download...'; sleep 1; fi
        done
        if [ "$downloaded" -ne 1 ]; then
            echo 'Download failed. Check the connection and that all package parts have been committed to main.' >&2; exit 1
        fi
        if ! valid "$TEMP" "$size" "$expected"; then echo "Downloaded part failed size/SHA-256 verification: $name" >&2; exit 1; fi
        mv -f "$TEMP" "$CACHE/$name"
        TEMP=''
    fi
done <<'ACADEMIC_PARTS'
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part001|24000000|e458ef82b02a17bc19ef4cda70fb39041bee70c4fa9e5bc81f79342be882b1e2
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part002|24000000|28acc2425bcc5dd384a225fbf2c2c5ccdf21e42007f4c4211e13fc3c0675b1f6
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part003|24000000|c539599821f5c5b74a6564ccea1f9c7cf6ffe5008e951e08d578bb75506c7ca5
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part004|24000000|41d6be4c45d320b5b2c6ad3df7d0cf1130df57a6102cc16b3f3e6c2287ba44b0
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part005|5435043|4b656c687d9732e4beef53787f6ce8483e074ed022ff9aec21642a3ec6e7efc6
ACADEMIC_PARTS
if [ ! -f "$CACHE/$ARCHIVE" ] || [ "$(digest "$CACHE/$ARCHIVE")" != "$ARCHIVE_HASH" ]; then
    echo 'Reconstructing the installer archive...'
    TEMP=$(mktemp "$CACHE/.assemble.XXXXXXXX")
    while IFS='|' read -r name size expected; do cat "$CACHE/$name" >> "$TEMP"; done <<'ACADEMIC_PARTS'
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part001|24000000|e458ef82b02a17bc19ef4cda70fb39041bee70c4fa9e5bc81f79342be882b1e2
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part002|24000000|28acc2425bcc5dd384a225fbf2c2c5ccdf21e42007f4c4211e13fc3c0675b1f6
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part003|24000000|c539599821f5c5b74a6564ccea1f9c7cf6ffe5008e951e08d578bb75506c7ca5
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part004|24000000|41d6be4c45d320b5b2c6ad3df7d0cf1130df57a6102cc16b3f3e6c2287ba44b0
PortalAI-Academic-Mac-Installer-20261020-r2-universal.tar.gz.part005|5435043|4b656c687d9732e4beef53787f6ce8483e074ed022ff9aec21642a3ec6e7efc6
ACADEMIC_PARTS
    if [ "$(digest "$TEMP")" != "$ARCHIVE_HASH" ]; then echo 'Reconstructed archive checksum failed.' >&2; exit 1; fi
    mv -f "$TEMP" "$CACHE/$ARCHIVE"
    TEMP=''
fi
PACKAGE="$SETUP/installer"
if [ ! -d "$PACKAGE" ]; then
    echo 'Extracting the verified installer...'
    STAGE=$(mktemp -d "$SETUP/.extract.XXXXXXXX")
    tar -xzf "$CACHE/$ARCHIVE" -C "$STAGE"
    [ -d "$STAGE/$TOP" ] || { echo 'Expected installer folder is missing.' >&2; exit 1; }
    mv "$STAGE/$TOP" "$PACKAGE"
    rmdir "$STAGE"
fi
while IFS='|' read -r name size expected; do
    if ! valid "$PACKAGE/$name" "$size" "$expected"; then
        echo "Extracted installer file is missing or changed: $name. Choose a new setup folder." >&2; exit 1
    fi
done <<'ACADEMIC_FILES'
install-macos.sh|7034|d48d40219a7eb1d414f7e6c2f71a85eb7e0e80ef37459ba20d9c5e3f644f7268
llama.cpp-source.tar.gz|38183379|55d67acf3ad2ad747a9bbeb75f9f0e173dbcc0d1753a471038a90c819421c5e1
manifest.json|3220|ac68ac1395f8b5e50dcad8f803163a6565419b3c3b5c063cefd3db57b143f212
payload.tar.gz|14180856|908a4d38c570fefb0348823f27903e6e15a16e226d32a2eb9b8053a1590ae4f1
python-runtime-arm64.tar.gz|25030095|233f8e15255b3e1d1fd47ea5dd5230dfed803f371138e896e54d98c60ae19f6f
python-runtime-x86_64.tar.gz|24751118|fb3187d95334813b88940db0f1ca57b84cedfd552739c3a5771c3ea0e49988c9
README.txt|4184|0bbb3a5ba6f79a777ce7d74c82dd5eddd79f0bdf7eb57c7622b5cd7b04be8a85
SHA256SUMS|607|81b1a7ab0210da3d75299e74a1233eeec4a7d2b43520d86c8e13a762fd0a0379
ACADEMIC_FILES
echo 'The complete Academic installer has been downloaded and verified.'
if [ "$PREPARE_ONLY" -eq 1 ]; then printf 'Prepared installer: %s\n' "$PACKAGE"; exit 0; fi
echo 'Starting the Academic installation. Additional runtime/model downloads may follow.'
bash "$PACKAGE/install-macos.sh" "$SETUP/PortalAI Academic Mac"
