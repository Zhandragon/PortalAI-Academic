// getRandomValues is available on direct HTTP HA origins as well as HTTPS.
// Do not replace this with Math.random, timestamps, or predictable identifiers.
export function randomId() {
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  return hex(bytes);
}

const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
const K = new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
]);
const rotate = (value, bits) => (value >>> bits) | (value << (32 - bits));

// File checksums only: not used for keys, authentication, or transport security.
// SubtleCrypto is HTTPS-only. Keep verification on HTTP using the same SHA-256
// algorithm, bounded to the existing transfer limit and yielding during work.
export async function sha256Hex(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength > 20 * 1024 * 1024)
    throw new Error('Checksum input must be bytes of at most 20 MiB');
  if (typeof globalThis.crypto?.subtle?.digest === 'function')
    return hex(new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', bytes)));
  const state = new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
  const words = new Uint32Array(64);
  function block(input, offset) {
    for (let i=0;i<16;i++) {
      const p=offset+i*4;
      words[i]=(input[p]<<24)|(input[p+1]<<16)|(input[p+2]<<8)|input[p+3];
    }
    for (let i=16;i<64;i++) {
      const x=words[i-15],y=words[i-2];
      words[i]=words[i-16]+(rotate(x,7)^rotate(x,18)^(x>>>3))+words[i-7]+(rotate(y,17)^rotate(y,19)^(y>>>10));
    }
    let [a,b,c,d,e,f,g,h]=state;
    for (let i=0;i<64;i++) {
      const t1=(h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^(~e&g))+K[i]+words[i])>>>0;
      const t2=((rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c)))>>>0;
      h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
    }
    for (const [i,value] of [a,b,c,d,e,f,g,h].entries()) state[i]+=value;
  }
  const complete=bytes.length-bytes.length%64;
  for (let offset=0;offset<complete;offset+=64) {
    block(bytes,offset);
    if ((offset+64)%262144===0) await new Promise(resolve=>setTimeout(resolve,0));
  }
  const remaining=bytes.length-complete;
  const tail=new Uint8Array(remaining<56?64:128);
  tail.set(bytes.subarray(complete));tail[remaining]=128;
  // The 20 MiB input bound keeps the high 32 bits of the bit length zero.
  new DataView(tail.buffer).setUint32(tail.length-4,bytes.length*8,false);
  for (let offset=0;offset<tail.length;offset+=64) block(tail,offset);
  return Array.from(state,value=>value.toString(16).padStart(8,'0')).join('');
}
