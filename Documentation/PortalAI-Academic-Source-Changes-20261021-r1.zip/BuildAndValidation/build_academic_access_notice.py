"""Add the approved access notice to Academic r2 and package a new Academic release.

Inputs are the verified Academic r2 build; the normal distribution and personal
installation are never modified. Run prepare, build, validate, then stage.
"""
from pathlib import Path
import ast, hashlib, importlib.util, io, json, shutil, subprocess, sys, tarfile, zipfile

WORK = Path(__file__).resolve().parent
BASE = WORK / 'academic-r2'
OUT = WORK / 'academic-20261021-r1'
REPO = WORK / 'github-publish'
RELEASE = '20261021-r1'
NOTICE = ('The unrestricted version of PortalAI is currently private to prevent misuse. '
          'To request access to the abliterated/uncensored PortalAI distribution repository, '
          'please contact genesislung@gmail.com')
CHANGED = ('ControlCenter/portal_frontend_v15136.py', 'Documentation/PortalAI_Academic.txt')

def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def dump(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

def replace_once(text, old, new):
    assert text.count(old) == 1, old[:120]
    return text.replace(old, new)

def prepare():
    for platform in ('Windows', 'Linux', 'Mac'):
        root = OUT / 'application' / platform / 'PortalAI'
        shutil.copytree(BASE / 'application' / platform / 'PortalAI', root,
                        dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        path = root / CHANGED[0]
        text = path.read_text(encoding='utf-8')
        begin = text.rindex('class WelcomeFeatureController:')
        end = text.index('\ndef install_welcome_feature(', begin)
        prefix, text, suffix = text[:begin], text[begin:end], text[end:]
        text = replace_once(text, 'self.frame = None; self.icon_label = None; self.tag1 = None; self.tag2 = None',
                            'self.frame = None; self.icon_label = None; self.tag1 = None; self.tag2 = None\n        self.access_note = None')
        text = replace_once(text, '        self.tag2.pack(fill="x", pady=(2, 0))\n        self.icon_label',
            '        self.tag2.pack(fill="x", pady=(2, 0))\n'
            '        # Academic distribution: access to the separate unrestricted repository is by request.\n'
            '        self.access_note = tk.Label(tagbox,\n'
            f'                             text={NOTICE!r},\n'
            '                             bg=p.get("bg"), fg=p.get("muted", p.get("text")),\n'
            '                             font=(portal_body_font(tagbox), 8), anchor="center",\n'
            '                             justify="center", wraplength=560)\n'
            '        self.access_note.pack(fill="x", padx=8, pady=(8, 0))\n'
            '        self.icon_label')
        text = replace_once(text,
            '        # Reserve ~50 px for both text lines, shrink the emblem before sacrificing text.\n'
            '        avail = max(80, min(w - 24, h - 54))\n'
            '        if avail >= 300: size = 320\n'
            '        elif avail >= 225: size = 240\n'
            '        elif avail >= 165: size = 180\n'
            '        elif avail >= 120: size = 128\n',
            '        # Reserve the wrapped notice and taglines before sizing the emblem.\n'
            '        self.access_note.configure(wraplength=max(160, w - 16))\n'
            '        text_height = (self.tag1.winfo_reqheight() + self.tag2.winfo_reqheight() +\n'
            '                       self.access_note.winfo_reqheight() + 22)\n'
            '        avail = max(80, min(w - 24, h - text_height))\n'
            '        if avail >= 320: size = 320\n'
            '        elif avail >= 240: size = 240\n'
            '        elif avail >= 180: size = 180\n'
            '        elif avail >= 128: size = 128\n')
        text = replace_once(text,
            'for wgt in (self.frame, self.icon_label, self.tag1.master, self.tag1, self.tag2):',
            'for wgt in (self.frame, self.icon_label, self.tag1.master, self.tag1, self.tag2, self.access_note):')
        text = replace_once(text, '            self.tag2.configure(fg=p.get("muted", p.get("text")))',
            '            self.tag2.configure(fg=p.get("muted", p.get("text")))\n'
            '            self.access_note.configure(fg=p.get("muted", p.get("text")))')
        text = replace_once(text, '                self.tag2.pack(fill="x", pady=(2, 0))',
            '                self.tag2.pack(fill="x", pady=(2, 0), before=self.access_note)')
        text = prefix + text + suffix
        # The live controller inherits its viewport refresh from this later revision.
        begin = text.index('class WelcomeFeatureController(_WelcomeFeatureController_v15_138A):')
        end = text.index('\ndef install_welcome_feature(', begin)
        prefix, text, suffix = text[:begin], text[begin:end], text[end:]
        text = replace_once(text, '        reserve = 58',
            '        self.access_note.configure(wraplength=max(160, width - 16))\n'
            '        reserve = (self.tag1.winfo_reqheight() + self.tag2.winfo_reqheight() +\n'
            '                   self.access_note.winfo_reqheight() + 22)')
        for old, new in ((292,320),(218,240),(168,180),(146,160),(114,128)):
            text = replace_once(text, f'avail >= {old}:', f'avail >= {new}:')
        text = replace_once(text,
            'for wgt in (self.frame, self.icon_label, self.tag1.master, self.tag1, self.tag2):',
            'for wgt in (self.frame, self.icon_label, self.tag1.master, self.tag1, self.tag2, self.access_note):')
        text = replace_once(text, '            self.tag2.configure(fg=p.get("muted", p.get("text")))',
            '            self.tag2.configure(fg=p.get("muted", p.get("text")))\n'
            '            self.access_note.configure(fg=p.get("muted", p.get("text")))')
        text = replace_once(text, '                self.tag2.pack(fill="x", pady=(2, 0))',
            '                self.tag2.pack(fill="x", pady=(2, 0), before=self.access_note)')
        text = prefix + text + suffix
        ast.parse(text)
        path.write_text(text, encoding='utf-8', newline='\n')
        path = root / CHANGED[1]
        text = path.read_text(encoding='utf-8')
        path.write_text(text + '\n2026-10-21 r1: Access to the separate unrestricted repository is by special request and approval only.\n' + NOTICE + '\n', encoding='utf-8', newline='\n')
    assert len({sha(OUT/'application'/p/'PortalAI'/CHANGED[0]) for p in ('Windows','Linux','Mac')}) == 1
    print('Prepared identical Academic welcome changes on all three platforms.', flush=True)

def build():
    for platform in ('Windows', 'Linux', 'Mac'):
        original = BASE / 'packages' / platform
        package = OUT / 'packages' / platform
        shutil.copytree(original, package, dirs_exist_ok=True)
        changes = {name: (OUT/'application'/platform/'PortalAI'/name).read_bytes() for name in CHANGED}
        manifest_name = 'release.json' if platform == 'Windows' else 'manifest.json'
        manifest = json.loads((package/manifest_name).read_bytes())
        manifest['release'] = manifest['release'].replace('2026.10.20-r2', '2026.10.21-r1')
        if platform == 'Windows':
            mapping = {r['member']: r for r in manifest['payload']['members']}
            with zipfile.ZipFile(original/'payload.zip') as old, zipfile.ZipFile(package/'payload.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as new:
                for info in old.infolist():
                    data = old.read(info)
                    if info.filename.startswith('PortalAI/'):
                        data = changes.get(info.filename.removeprefix('PortalAI/'), data)
                    new.writestr(info, data)
                    if not info.is_dir(): mapping[info.filename].update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
            manifest['payload'].update(bytes=(package/'payload.zip').stat().st_size,sha256=sha(package/'payload.zip'))
            source = OUT / 'installer-source'
            shutil.copytree(BASE/'installer-source', source, dirs_exist_ok=True)
            path = source/'Installer.cs'
            path.write_text(path.read_text().replace('2026.10.20 r2','2026.10.21 r1'))
            args = ['C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe','/nologo','/target:winexe','/optimize+','/out:'+str(package/'PortalAI-Academic-Install.exe')]
            args += ['/reference:'+n for n in ('System.Windows.Forms.dll','System.Drawing.dll','System.Web.Extensions.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')]
            args += ['/resource:'+str(WORK/'python-bootstrap.zip')+',python-bootstrap.zip']
            args += ['/resource:'+str(source/n)+','+n for n in ('installer_core.py','engine_cli.py','academic_policy.py')]
            subprocess.run(args+[str(source/'Installer.cs')],check=True)
        else:
            with tarfile.open(original/'payload.tar.gz') as old, tarfile.open(package/'payload.tar.gz','w:gz',compresslevel=6) as new:
                for info in old:
                    if not info.isfile(): new.addfile(info); continue
                    data = old.extractfile(info).read()
                    if info.name.startswith('PortalAI/'):
                        data = changes.get(info.name.removeprefix('PortalAI/'),data)
                    info.size = len(data)
                    new.addfile(info,io.BytesIO(data))
            item = {'bytes': (package/'payload.tar.gz').stat().st_size, 'sha256': sha(package/'payload.tar.gz')}
            if platform == 'Linux': manifest['components']['payload.tar.gz'] = item
            else:
                manifest['artifacts']['payload.tar.gz'] = item
                manifest['application'].update(payload_sha256=item['sha256'],payload_bytes=item['bytes'])
        dump(package/manifest_name, manifest)
        for name in ('START_HERE.txt','README.txt'):
            path = package/name
            if path.exists():
                path.write_text('CURRENT: Academic 2026-10-21 r1. Welcome-panel access notice added; prior Academic behavior retained.\n\n' + path.read_text(encoding='utf-8'),encoding='utf-8')
        if platform == 'Windows':
            dump(package/'PACKAGE_SHA256.json',[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(package.iterdir()) if p.is_file() and p.name not in ('PACKAGE_SHA256.json','installer-selfcheck.json')])
            archive = OUT/'packages'/f'PortalAI-Academic-Windows-Installer-{RELEASE}-x64.zip'
            with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for p in sorted(package.iterdir()):
                    if p.is_file() and p.name != 'installer-selfcheck.json': z.write(p,p.name)
        else:
            (package/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(package.iterdir()) if p.is_file() and p.name != 'SHA256SUMS'))
            arch = 'x86_64' if platform == 'Linux' else 'universal'
            archive = OUT/'packages'/f'PortalAI-Academic-{platform}-Installer-{RELEASE}-{arch}.tar.gz'
            with tarfile.open(archive,'w:gz',compresslevel=6) as t:
                for p in sorted(package.iterdir()):
                    if not p.is_file(): continue
                    info = t.gettarinfo(str(p),arcname=f'PortalAI-Academic-{platform}-Installer-{RELEASE}/'+p.name)
                    info.mode = 0o755 if p.suffix=='.sh' else 0o644
                    info.uid=info.gid=0;info.uname=info.gname=''
                    with p.open('rb') as f: t.addfile(info,f)
        print('Built', RELEASE, platform, flush=True)

def validate():
    report = {'release': RELEASE, 'scope': 'Package integrity, exact source delta from Academic r2 and syntax checks on Windows. No physical Linux/macOS install or model inference was run.', 'platforms': {}}
    for platform in ('Windows','Linux','Mac'):
        original = BASE/'packages'/platform
        package = OUT/'packages'/platform
        manifest = json.loads((package/('release.json' if platform=='Windows' else 'manifest.json')).read_bytes())
        def payload_items(p):
            if platform == 'Windows':
                with zipfile.ZipFile(p/'payload.zip') as z:
                    return {i.filename:hashlib.sha256(z.read(i)).hexdigest() for i in z.infolist() if not i.is_dir()}
            with tarfile.open(p/'payload.tar.gz') as t:
                return {i.name:hashlib.sha256(t.extractfile(i).read()).hexdigest() for i in t if i.isfile()}
        before, after = payload_items(original), payload_items(package)
        assert before.keys()==after.keys()
        changed = sorted(n for n in before if before[n]!=after[n])
        assert changed == sorted('PortalAI/'+name for name in CHANGED), changed
        dest = OUT/'verify'/platform; dest.mkdir(parents=True,exist_ok=True)
        if platform == 'Windows':
            assert sha(package/'payload.zip')==manifest['payload']['sha256']
            with zipfile.ZipFile(package/'payload.zip') as z:
                for row in manifest['payload']['members']:
                    data=z.read(row['member'])
                    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
                z.extractall(dest)
            for row in json.loads((package/'PACKAGE_SHA256.json').read_bytes()):
                assert sha(package/row['path'])==row['sha256']
            subprocess.run([str(package/'PortalAI-Academic-Install.exe'),'--verify-bootstrap'],check=True,timeout=60)
        else:
            expected = manifest['components' if platform=='Linux' else 'artifacts']['payload.tar.gz']
            assert sha(package/'payload.tar.gz')==expected['sha256']
            for line in (package/'SHA256SUMS').read_text().splitlines():
                digest,name=line.split('  ',1);assert sha(package/name)==digest
            with tarfile.open(package/'payload.tar.gz') as t:t.extractall(dest,filter='data')
            subprocess.run(['C:/Program Files/Git/bin/bash.exe','-n',str(package/('install.sh' if platform=='Linux' else 'install-macos.sh'))],check=True)
        for name in CHANGED:
            data = (dest/'PortalAI'/name).read_text(encoding='utf-8')
            assert NOTICE in data
            if name.endswith('.py'): ast.parse(data)
        report['platforms'][platform]={'passed':True,'payload_files':len(after),'changed_payload_files':changed,'other_payload_files_identical_to_r2':len(after)-len(changed)}
        print('Validated',platform,flush=True)
    dump(OUT/'VALIDATION.json',report)

def stage():
    report = json.loads((OUT/'VALIDATION.json').read_bytes())
    assert all(p['passed'] for p in report['platforms'].values())
    metadata=json.loads((REPO/'PACKAGING.json').read_bytes());metadata['release']=RELEASE
    for platform in ('Windows','Linux','Mac'):
        archive=next((OUT/'packages').glob('*'+platform+'*.*gz' if platform!='Windows' else '*Windows*.zip'))
        package={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'path':f'packages/{RELEASE}/{platform}','parts':[],'files':[]}
        folder=REPO/package['path'];folder.mkdir(parents=True,exist_ok=True)
        with archive.open('rb') as f:
            index=1
            while data:=f.read(24_000_000):
                name=archive.name+f'.part{index:03d}';(folder/name).write_bytes(data)
                package['parts'].append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});index+=1
        if platform=='Windows':
            with zipfile.ZipFile(archive) as z:
                for item in z.infolist():
                    if item.is_dir():continue
                    data=z.read(item);package['files'].append({'name':item.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        else:
            with tarfile.open(archive) as t:
                for item in t:
                    if not item.isfile():continue
                    top,name=item.name.split('/',1);package['top_folder']=top
                    data=t.extractfile(item).read();package['files'].append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        metadata['packages'][platform]=package
    dump(REPO/'PACKAGING.json',metadata)
    # Keep the previous detailed policy validation available as historical evidence.
    historical=REPO/'Documentation/VALIDATION-20261020-r2.json'
    if not historical.exists():shutil.copyfile(BASE/'VALIDATION.json',historical)
    shutil.copyfile(OUT/'VALIDATION.json',REPO/'Documentation/VALIDATION.json')
    archive=OUT/f'PortalAI-Academic-Source-Changes-{RELEASE}.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for platform in ('Windows','Linux','Mac'):
            for name in CHANGED:z.write(OUT/'application'/platform/'PortalAI'/name,platform+'/ChangedFiles/PortalAI/'+name)
        z.write(OUT/'installer-source/Installer.cs','Windows/Installer/Installer.cs')
        z.write(Path(__file__),'BuildAndValidation/'+Path(__file__).name)
        z.write(OUT/'VALIDATION.json','VALIDATION.json')
    shutil.copyfile(archive,REPO/'Documentation'/archive.name)
    for name in ('Bootstrapper.cs.in','native.sh.in'):
        path=REPO/'bootstrap-source'/name
        path.write_text(path.read_text(encoding='utf-8').replace('20261020-r2',RELEASE),encoding='utf-8',newline='\n')
    path=REPO/'bootstrap-source/build.py'
    path.write_text(path.read_text(encoding='utf-8').replace("'20261020.2'","'20261021.1'").replace('(2026, 10, 20, 0, 0, 0)','(2026, 10, 21, 0, 0, 0)'),encoding='utf-8',newline='\n')
    spec=importlib.util.spec_from_file_location('academic_online_build',REPO/'bootstrap-source/build.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    print(json.dumps(module.build(REPO),indent=2))

if __name__=='__main__':
    {'prepare':prepare,'build':build,'validate':validate,'stage':stage}[sys.argv[1]]()
