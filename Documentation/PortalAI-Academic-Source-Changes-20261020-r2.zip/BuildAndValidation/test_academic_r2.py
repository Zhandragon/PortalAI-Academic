from pathlib import Path
import json, sys, tempfile, unittest
from unittest.mock import patch

ROOT=Path(sys.argv.pop(1)).resolve()
sys.path[:0]=[str(ROOT/'Agent'),str(ROOT/'ControlCenter'),str(ROOT/'Tools')]
import academic_policy as policy

class AcademicR2(unittest.TestCase):
    def test_nested_and_numbered_loader_names_are_rejected(self):
        for inputs in ({'lora_name_1':'f_anatomical_high.safetensors'},
                       {'loras':[{'lora_name':'anatomical.safetensors','strength':1}]},
                       {'model_path':'models/%61bliterated.gguf'},
                       {'adapter_options':{'filename':'genitalia.safetensors'}},
                       {'clip_name':'qwen-uncensored.gguf'}):
            with self.subTest(inputs=inputs):
                with self.assertRaisesRegex(ValueError,'academic version'):
                    policy.check_workflow({'1':{'class_type':'MultiLoader','inputs':inputs}})

    def test_prose_and_graph_links_are_not_asset_names(self):
        wf={'uncensored':{'class_type':'CLIPTextEncode','inputs':{'text':'Explain anatomical terminology in education; the word uncensored is prose.'}},
            '2':{'class_type':'KSampler','inputs':{'model':['uncensored',0]}}}
        self.assertIs(policy.check_workflow(wf),wf)

    def test_invalid_workflow_shape_has_controlled_error(self):
        for wf in ([], {'1':{'inputs':[]}}):
            with self.assertRaises(ValueError):policy.check_workflow(wf)

    def test_known_excluded_hash_cannot_be_relabelled(self):
        digest=next(iter(policy.KNOWN_EXCLUDED_DIGESTS))
        for row in ({'id':'standard-model','sha256':digest},
                    {'id':'standard-archive','members':[{'dest':'models/standard.gguf','sha256':digest}]}):
            self.assertFalse(policy.asset_allowed(row))
        self.assertTrue(policy.asset_allowed({'id':'ordinary','sha256':'0'*64}))

    def test_inventory_marks_omitted_rows_excluded(self):
        import bundle_inventory
        with tempfile.TemporaryDirectory() as folder,patch.object(bundle_inventory,'inventory',return_value={'models':[],'backends':{},'backend_states':{}}):
            rows=bundle_inventory.installed_rows(Path(folder))
            for name in policy.MODEL_COUNTERPARTS:
                self.assertEqual(rows['model_'+name][0],'EXCLUDED')
            self.assertEqual(rows['fluxAlt'][0],'EXCLUDED')

    def test_discovery_has_no_active_alternate_assets(self):
        import model_variants
        with tempfile.TemporaryDirectory() as folder:
            result=model_variants.catalog(root=Path(folder),check_files=True)
        self.assertFalse(result['uncensored_available'])
        self.assertEqual(result['media_default'],'standard')
        for row in result['models']:
            self.assertFalse(row.get('uncensored'))
            self.assertNotIn('uncensored_source',row)
            self.assertNotIn('closest_alternatives',row)

    def test_no_legacy_mission_or_settings_instruction(self):
        mission=(ROOT/'Agent/mission_runner.py').read_text(encoding='utf-8')
        settings=(ROOT/'ControlCenter/settings_page.py').read_text(encoding='utf-8')
        self.assertNotIn('Media auto permits a supported per-request --uncensored',mission)
        self.assertNotIn('It follows Uncensored',settings)
        import help_catalog
        self.assertIn('locked to standard',help_catalog.TOPICS['settings']['body'])

    def test_standard_graphs_still_pass(self):
        files=list((ROOT/'Workflows/API').glob('*.json'))
        self.assertTrue(files)
        for path in files:policy.check_workflow(json.loads(path.read_bytes()))

if __name__=='__main__':unittest.main(verbosity=2)
